#Variety seeking Study 1
#https://rosiethuypham.shinyapps.io/VSFit/

library(shiny) 
library(tidyverse)
library(ggplot2)

data.vs <- read.csv("dataS2.csv")

data.vs <- dplyr::rename(data.vs, fit = VS)

RMP.lm <- lm(fit ~ RFP * RMP, data = data.vs)

summary(RMP.lm)

ui <- fluidPage(
    
    titlePanel(
        title = h2("How Fit and Nonfit between Regulatory Focus and Mode impact Variety Seeking: Model Predictions", align="left"),
        windowTitle = "How Fit and Nonfit between Regulatory Focus and Mode impact Variety Seeking: Model Predictions"
    ),
    
    sidebarLayout(position = "right",
                  sidebarPanel(
                      htmlOutput("predstatement3"),
                      br(),
                      sliderInput("RFP", "Predominant Regulatory Focus (a positive value indicates a promotion predominance, whereas a negative value indicates a prevention predominance):",
                                  min = -2, max = 2,
                                  value = 0, step = .1),
                      sliderInput("RMP", "Predominant Regulatory Mode (a positive value indicates a locomotion predominance, whereas a negative value indicates an assessment predominance):",
                                  min = -2, max = 2,
                                  value = 0, step = .1),
                  ),
                  mainPanel(
                      htmlOutput("predstatement1"),
                      br(),
                      plotOutput("plot2"),
                      br(),
                      br(),
                      p("The model prediction is generated from Study 2 in the manuscript entitled 'How Fit and Nonfit between Regulatory Focus and Mode Impacts Variety Seeking'. Under review at the",
                        span("Journal of Consumer Psychology.", style = "font-style:italic"))
                  )
    )
)

server <- function(input, output){
    RMP.lm <- reactive({
        RMP.lm <- lm(fit ~ RFP * RMP, data = data.vs)
    })
    
    pred.data <- reactive({
        pred.data <- data.frame(RMP = seq(-2, 2, .1), RFP = input$RFP)
    })
    
    RMP.lm.pred <- reactive({
        RMP.lm.pred <- cbind(pred.data(), 
                             predict(RMP.lm(), pred.data(), 
                                     interval = "confidence", 
                                     type = c("response", "terms")))
    })
    
    user.pred.data <- reactive({
        user.pred.data <- data.frame(RFP = input$RFP, RMP = input$RMP)
    })
    
    user.pred <- reactive({
        user.pred <- cbind(user.pred.data(), 
                           predict(RMP.lm(), user.pred.data(), 
                                   interval = "confidence", 
                                   type = c("response", "terms")))
    })
    
    user.pred.per.ch <- reactive({
        user.pred.per.ch <- cbind(user.pred.data(),
                                  predict(Per.Ch(), user.pred.data(),
                                          interval = "confidence", 
                                          type = c("response", "terms")))
        
    })
    
    output$predstatement1 <- renderText({
        print(paste0("<div style = \"font-size:18px\">Based on the input values you selected, the model predicts a variety seeking score of <font color = \"black\">", 
                     round(user.pred()$fit, digits = 2),"%</font color></b>. In other word, <b><font color = \"red\">", 
                     round(user.pred()$fit, digits = 2),"%</font color></b> of the selected options are different. Variety seeking score takes a maximum value of 100%
                     when all the selected options are different. </div>"))
        
    })
    
    output$predstatement3 <- renderText({
        print(paste0("<div style = \"font-size:14px\">Please choose a value on each sliding bar below.</div>"))
        
    })
    
    output$plot2 <- renderPlot({
        ggplot(data = data.vs, aes(x = RMP, y = fit)) +
            xlim(-2, 2) +
            ylim(0, 100) +
            geom_segment(data = user.pred(), aes(x = -2, y = fit, xend = RMP, yend = fit), linetype = "dashed") +
            geom_segment(data = user.pred(), aes(x = RMP, y = 0, xend = RMP, yend = fit), linetype = "dashed") +
            geom_ribbon(data = RMP.lm.pred(), aes(ymin = lwr, ymax = upr), alpha = .3, fill = "gray") +
            geom_line(data = RMP.lm.pred(), color = "black", size = 1) +
            geom_point(data = user.pred(), color = "red", size = 7) +
        labs(title="Regulatory Focus and Mode as Predictors of Variety Seeking", x="Predominant Locomotion Regulatory Mode", y="Variety seeking (%)")
    })

}

shinyApp(ui, server)

