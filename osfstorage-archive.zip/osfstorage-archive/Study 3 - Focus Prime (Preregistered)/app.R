# JCP Submission: How Regulatory Focus-Mode Fit Impacts Variety-Seeking
# Study 3 (Preregistered)

library(shiny) 
library(tidyverse)
library(ggplot2)

data.S4 <- read.csv("VS_S4_Jun1_R.csv")
data.S4 <- dplyr::rename(data.S4, fit = VSHLNP)
ui <- fluidPage(
    titlePanel(
        title = h2("How Fit and Nonfit between Regulatory Focus and Mode impact Variety Seeking: Model Predictions", align="left"),
        windowTitle = "How Fit and Nonfit between Regulatory Focus and Mode impact Variety Seeking: Model Predictions"
    ),
    
    sidebarLayout(position = "right",
                  sidebarPanel(
                      selectInput("condition", "Condition:", 
                                  choices=c("Promotion Regulatory Focus","Prevention Regulatory Focus")),
                      sliderInput("LPA", "Predominant Regulatory Mode (a positive value indicates a locomotion predominance, whereas a negative value indicates an assessment predominance):",
                                  min = -3, max = 3,
                                  value = 0, step = 0.1),
                  ),
                  mainPanel(
                      htmlOutput("predstatement"),
                      br(),
                      plotOutput("plot2"),
                      br(),
                      p(span("Note: In Study 3 (preregistered), we primed regulatory focus and measured regulatory mode. Findings from this study suggest that fit between regulatory focus and mode decreases variety seeking (for instance, fit between promotion and locomotion, or prevention and assessment). In the promotion regulatory focus condition, customers seek less variety when they are predominant in locomotion and vice versa. In the prevention regulatory focus condition, customers seek less variety when they are predominant in assessment and vice versa.", style = "font-size:12px")),
                      p(span("References", style = "font-weight:bold")),
                      p("The model prediction is generated from Study 3 in the manuscript entitled 'How Fit and Nonfit between Regulatory Focus and Mode Impacts Variety Seeking'. Under review at the",
                        span("Journal of Consumer Psychology.", style = "font-style:italic")),
                  )
    )
)

server <- function(input, output){
    
    rfcfl.promctr <- reactive({
        rfcfl.promctr <- lm(fit ~ LPA * condition , data = data.S4)
    })
    
    pred.data <- reactive({
        pred.data <- data.frame(LPA = seq(-2.9, 3, .1), condition = input$condition)
    })
    
    rfcfl.promctr.pred <- reactive({
        rfcfl.promctr.pred <- cbind(pred.data(), 
                                    predict(rfcfl.promctr(), pred.data(), 
                                            interval = "confidence", 
                                            type = c("response", "terms")))
    })
    
    user.pred.data <- reactive({
        user.pred.data <- data.frame(LPA = input$LPA, condition = input$condition)
    })
    
    user.pred <- reactive({
        user.pred <- cbind(user.pred.data(), 
                           predict(rfcfl.promctr(), user.pred.data(), 
                                   interval = "confidence", 
                                   type = c("response", "terms")))
    })
 
    output$predstatement <- renderText({
        print(paste0("<div style = \"font-size:18px\">Based on the values you selected for regulatory focus and mode, the model predicts a variety seeking score of <font color = \"black\">", 
                     round(user.pred()$fit, digits = 2),"%</font color></b>. In other words, <b><font color = \"red\">", 
                     round(user.pred()$fit, digits = 2),"%</font color></b> of the selected options are unique. The variety seeking score takes a maximum value of 100% when all the selected options are unique. </div>"))
        
    })
    
    output$plot2 <- renderPlot({
        ggplot(data = data.S4, aes(x = LPA, y = fit)) +
            xlim(-2.9, 3) +
            ylim(0, 100) +
            geom_segment(data = user.pred(), aes(x = -2.9, y = fit, xend = LPA, yend = fit), linetype = "dashed") +
            geom_segment(data = user.pred(), aes(x = LPA, y = 0, xend = LPA, yend = fit), linetype = "dashed") +
            geom_ribbon(data = rfcfl.promctr.pred(), aes(ymin = lwr, ymax = upr), alpha = .3, fill = "gray") +
            geom_line(data = rfcfl.promctr.pred(), color = "black", size = 1) +
            geom_point(data = user.pred(), color = "red", size = 7) +
            labs(title="Regulatory Focus and Mode as Predictors of Variety Seeking", x="Predominant Regulatory Mode", y="Variety seeking (%)", color = "Condition")
    })
    
}

shinyApp(ui, server)

