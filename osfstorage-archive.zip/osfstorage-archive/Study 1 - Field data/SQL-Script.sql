-- JCP submission: "How Regulatory Focus-Mode Fit Impacts Variety-Seeking"
-- MySQL code to extract data from the database
-- User No, User Id, Unique Genres, Unique Songs, Total Songs until 28 Feb 2021
-- !preview conn=DBI::dbConnect(RSQLite::SQLite())

set session group_concat_max_len = 18446744073709551615;
select 
id as `User No`,
hashId as `User ID`,
(select count(distinct(GenreId)) from SongPlay,Tracks,ArtistGenres where personId=Persons.id and SongPlay.TrackId=Tracks.id and Tracks.ArtistId=ArtistGenres.ArtistId and ArtistGenres.GenreId < 3802 and SongPlay.createdAt < '2021-02-28') as `Unique Genres Listened`,
(select count(distinct(TrackId)) from SongPlay where SongPlay.personId=Persons.id and SongPlay.createdAt < '2021-02-28') as `Unique songs`,
(select count(*) from SongPlay where personId=Persons.id and SongPlay.createdAt < '2021-02-28') as `Total songs`
from Persons
where (select count(distinct(GenreId)) from SongPlay,Tracks,ArtistGenres where personId=Persons.id and SongPlay.TrackId=Tracks.id and Tracks.ArtistId=ArtistGenres.ArtistId and ArtistGenres.GenreId < 3802 and SongPlay.createdAt < '2021-02-28') > 0
and (select count(distinct(TrackId)) from SongPlay where personId=Persons.id and SongPlay.createdAt < '2021-02-28') > 0
and (select count(distinct(ArtistId)) from SongPlay,Tracks where SongPlay.trackId=Tracks.id and SongPlay.personId=Persons.id and SongPlay.createdAt < '2021-02-28') > 0
order by id
limit 50 
