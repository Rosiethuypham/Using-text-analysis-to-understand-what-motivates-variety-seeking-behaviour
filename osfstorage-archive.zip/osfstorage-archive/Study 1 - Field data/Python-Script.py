# JCP Submission: How Regulatory Focus-Mode Fit Impacts Variety-Seeking

# Python (Add artist changed column to CSV exported from SQL):

import csv
import sys

last = {}

print '"User No","User ID","latitude","longitude","year","Post","comment","Artist","likeCount","Share count","wordCount","genreCount","genres","artistChanged"'

def fix_nulls(s):
    for line in s:
        yield line.replace('\0', ' ')

file = fix_nulls(open('ordered_by_post.csv'))
reader = csv.reader(file, delimiter=',', skipinitialspace=True, escapechar='\\')
writer = csv.writer(sys.stdout)
line = 0
for row in reader:
    changed = 0
    if line > 0:
        try:
            if last[row[0]] == row[7]:
                changed = 1
        except KeyError as e:
            None 
        last[row[0]] = row[7]
        row.append(changed)
        writer.writerow(row)
    line += 1


#Python (Generate totals from CSV exported from SQL):

import csv
import sys

data = {}

def fix_nulls(s):
    for line in s:
        yield line.replace('\0', ' ')

file = fix_nulls(open('ordered_by_post.csv'))
reader = csv.reader(file, delimiter=',', skipinitialspace=True, escapechar='\\')
writer = csv.writer(sys.stdout)
line = 0
for row in reader:
    if line > 0:
        id = row[0]
        if id not in data:
            data[id] = {}
            data[id]['userId'] = row[1]
            data[id]['lastArtist'] = 0
            data[id]['posts'] = 0
            data[id]['likes'] = 0
            data[id]['shares'] = 0
            data[id]['words'] = 0
            data[id]['genres'] = 0
            data[id]['comments'] = ""
            data[id]['artistChanges'] = 0

        if data[id]['lastArtist'] != row[7]:
            data[id]['artistChanges'] += 1

        data[id]['posts'] += 1
        data[id]['likes'] += int(0 if row[8] == "NULL" else row[8]) # Likes count
        data[id]['shares'] += int(0 if row[9] == "NULL" else row[9]) # Shares count
        data[id]['words'] += int(0 if row[10] == "NULL" else row[10]) # Word count
        data[id]['genres'] += int(0 if row[11] == "NULL" else row[11]) # Genre count
        data[id]['lastArtist'] = row[7]
        space = "" if len(data[id]['comments']) == 0 else " "
        data[id]['comments'] += "" if row[6] == "NULL" else "%s%s" % (space, row[6]) # Comments

    line += 1

print '"User No","User ID","Total Posts","Total Switch Artist","Total Words","Total Likes","Total Shares","Total Genres","Comments"'

# Order by User ID
keys = [int(string) for string in data.keys()]
keys.sort()

for id in keys:
	value = data[str(id)]
	row = [ id, value['userId'], value['posts'], value['artistChanges'], value['words'], value['likes'], value['shares'], value['genres'], value['comments'] ]
	writer.writerow(row)
